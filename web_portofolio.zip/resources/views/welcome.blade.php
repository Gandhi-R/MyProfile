<!DOCTYPE html>
<html lang="en" class="scroll-smooth overflow-x-hidden">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gandhi Rahmawan | Portfolio</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="bg-neo-white font-sans antialiased overflow-x-hidden">

    <x-navbar />

    <main>
        <x-home />
        <x-about />
        <x-project :project="$projects" />
        <x-skills :skills="$skills" />
        <x-github :stats="$stats" />
        <x-certificate :certificates="$certificates" />
        <x-contact />
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const modal = document.getElementById('pdfModal');
            const modalFrame = document.getElementById('pdfModalFrame');
            const closeBtn = document.getElementById('pdfModalClose');
            const detailButtons = document.querySelectorAll('.cert-detail-btn');

            detailButtons.forEach(function (btn) {
                btn.addEventListener('click', function () {
                    const pdfUrl = btn.getAttribute('data-pdf');
                    modalFrame.setAttribute('src', pdfUrl);
                    modal.classList.add('active');
                });
            });

            closeBtn.addEventListener('click', function () {
                closeModal();
            });

            modal.addEventListener('click', function (e) {
                if (e.target === modal) {
                    closeModal();
                }
            });

            function closeModal() {
                modal.classList.remove('active');
                modalFrame.setAttribute('src', '');
            }
        });
    </script>
</body>

</html>