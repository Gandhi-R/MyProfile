<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['skills']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['skills']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<section id="skills" class="page-section section-skills">
    <div class="skills-container">

        <!-- Banner Judul Gantung -->
        <div class="skills-title-wrapper">
            <div class="skills-line left-line"></div>
            <div class="skills-line right-line"></div>
            <div class="skills-banner">SKILLS</div>
        </div>

        <!-- Grid Kotak Skill -->
        <div class="skills-grid">

            <!-- Skill 1: React -->
            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-react.svg')); ?>" alt="React" class="skill-icon">
                <span class="skill-name">REACT</span>
            </div>

            <!-- Skill 2: C / C++ (Logo C yang di figma tulisannya Django wkwk) -->
            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-c.svg')); ?>" alt="C" class="skill-icon">
                <span class="skill-name">C / C++</span>
            </div>

            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-kali.svg')); ?>" alt="C" class="skill-icon">
                <span class="skill-name">KALILINUX</span>
            </div>

            <!-- Skill 3: Python -->
            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-python.svg')); ?>" alt="Python" class="skill-icon">
                <span class="skill-name">PYTHON</span>
            </div>

            <!-- Skill 4: PHP -->
            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-php.svg')); ?>" alt="PHP" class="skill-icon">
                <span class="skill-name">PHP</span>
            </div>

            <!-- Skill 5: GitHub -->
            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-github.svg')); ?>" alt="GitHub" class="skill-icon">
                <span class="skill-name">GITHUB</span>
            </div>

            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-laravel.svg')); ?>" alt="Laravel" class="skill-icon">
                <span class="skill-name">LARAVEL</span>
            </div>

            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-hack.svg')); ?>" alt="HackTheBox" class="skill-icon">
                <span class="skill-name">HACKTHEBOX</span>
            </div>

            <div class="skill-card">
                <img src="<?php echo e(asset('images/icons/icon-nmap.svg')); ?>" alt="Nmap" class="skill-icon">
                <span class="skill-name">NMAP</span>
            </div>

        </div>

    </div>
</section><?php /**PATH C:\laragon\www\myprofile\resources\views/components/skills.blade.php ENDPATH**/ ?>