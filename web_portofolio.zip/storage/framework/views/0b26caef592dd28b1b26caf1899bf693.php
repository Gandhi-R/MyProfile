<!DOCTYPE html>
<html lang="en" class="scroll-smooth overflow-x-hidden">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gandhi Rahmawan | Portfolio</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-neo-white font-sans antialiased overflow-x-hidden">

    <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>

    <main>
        <?php if (isset($component)) { $__componentOriginalfef18b83dad9fb9f477934ba01c89ca2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfef18b83dad9fb9f477934ba01c89ca2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfef18b83dad9fb9f477934ba01c89ca2)): ?>
<?php $attributes = $__attributesOriginalfef18b83dad9fb9f477934ba01c89ca2; ?>
<?php unset($__attributesOriginalfef18b83dad9fb9f477934ba01c89ca2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfef18b83dad9fb9f477934ba01c89ca2)): ?>
<?php $component = $__componentOriginalfef18b83dad9fb9f477934ba01c89ca2; ?>
<?php unset($__componentOriginalfef18b83dad9fb9f477934ba01c89ca2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalff6de83cb070587833d4f86022c57961 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6de83cb070587833d4f86022c57961 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.about','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6de83cb070587833d4f86022c57961)): ?>
<?php $attributes = $__attributesOriginalff6de83cb070587833d4f86022c57961; ?>
<?php unset($__attributesOriginalff6de83cb070587833d4f86022c57961); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6de83cb070587833d4f86022c57961)): ?>
<?php $component = $__componentOriginalff6de83cb070587833d4f86022c57961; ?>
<?php unset($__componentOriginalff6de83cb070587833d4f86022c57961); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal05abf2fa971c7c7019801b13e56745fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal05abf2fa971c7c7019801b13e56745fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.project','data' => ['project' => $projects]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['project' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($projects)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal05abf2fa971c7c7019801b13e56745fa)): ?>
<?php $attributes = $__attributesOriginal05abf2fa971c7c7019801b13e56745fa; ?>
<?php unset($__attributesOriginal05abf2fa971c7c7019801b13e56745fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05abf2fa971c7c7019801b13e56745fa)): ?>
<?php $component = $__componentOriginal05abf2fa971c7c7019801b13e56745fa; ?>
<?php unset($__componentOriginal05abf2fa971c7c7019801b13e56745fa); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale72b204ac71858b9ad76b935a89a8c0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale72b204ac71858b9ad76b935a89a8c0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skills','data' => ['skills' => $skills]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skills'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['skills' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($skills)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale72b204ac71858b9ad76b935a89a8c0f)): ?>
<?php $attributes = $__attributesOriginale72b204ac71858b9ad76b935a89a8c0f; ?>
<?php unset($__attributesOriginale72b204ac71858b9ad76b935a89a8c0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale72b204ac71858b9ad76b935a89a8c0f)): ?>
<?php $component = $__componentOriginale72b204ac71858b9ad76b935a89a8c0f; ?>
<?php unset($__componentOriginale72b204ac71858b9ad76b935a89a8c0f); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal925c7dc0f3eb36161ac26fb0cdac57c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal925c7dc0f3eb36161ac26fb0cdac57c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.github','data' => ['stats' => $stats]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('github'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['stats' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal925c7dc0f3eb36161ac26fb0cdac57c4)): ?>
<?php $attributes = $__attributesOriginal925c7dc0f3eb36161ac26fb0cdac57c4; ?>
<?php unset($__attributesOriginal925c7dc0f3eb36161ac26fb0cdac57c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal925c7dc0f3eb36161ac26fb0cdac57c4)): ?>
<?php $component = $__componentOriginal925c7dc0f3eb36161ac26fb0cdac57c4; ?>
<?php unset($__componentOriginal925c7dc0f3eb36161ac26fb0cdac57c4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalf766ebaa7b591205ba9cd6c32d25d6d3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf766ebaa7b591205ba9cd6c32d25d6d3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.certificate','data' => ['certificates' => $certificates]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('certificate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['certificates' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($certificates)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf766ebaa7b591205ba9cd6c32d25d6d3)): ?>
<?php $attributes = $__attributesOriginalf766ebaa7b591205ba9cd6c32d25d6d3; ?>
<?php unset($__attributesOriginalf766ebaa7b591205ba9cd6c32d25d6d3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf766ebaa7b591205ba9cd6c32d25d6d3)): ?>
<?php $component = $__componentOriginalf766ebaa7b591205ba9cd6c32d25d6d3; ?>
<?php unset($__componentOriginalf766ebaa7b591205ba9cd6c32d25d6d3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalef4cc57ced9b28544dce586d33e591dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef4cc57ced9b28544dce586d33e591dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef4cc57ced9b28544dce586d33e591dd)): ?>
<?php $attributes = $__attributesOriginalef4cc57ced9b28544dce586d33e591dd; ?>
<?php unset($__attributesOriginalef4cc57ced9b28544dce586d33e591dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef4cc57ced9b28544dce586d33e591dd)): ?>
<?php $component = $__componentOriginalef4cc57ced9b28544dce586d33e591dd; ?>
<?php unset($__componentOriginalef4cc57ced9b28544dce586d33e591dd); ?>
<?php endif; ?>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const modal = document.getElementById('pdfModal');
            const modalFrame = document.getElementById('pdfModalFrame');
            const closeBtn = document.getElementById('pdfModalClose');
            const detailButtons = document.querySelectorAll('.cert-detail-btn');

            detailButtons.forEach(function (btn) {
                btn.addEventListener('click', function () {
                    const pdfUrl = btn.getAttribute('data-pdf');
                    modalFrame.setAttribute('src', pdfUrl);
                    modal.classList.add('active');
                });
            });

            closeBtn.addEventListener('click', function () {
                closeModal();
            });

            modal.addEventListener('click', function (e) {
                if (e.target === modal) {
                    closeModal();
                }
            });

            function closeModal() {
                modal.classList.remove('active');
                modalFrame.setAttribute('src', '');
            }
        });
    </script>
</body>

</html><?php /**PATH C:\laragon\www\myprofile\resources\views/welcome.blade.php ENDPATH**/ ?>